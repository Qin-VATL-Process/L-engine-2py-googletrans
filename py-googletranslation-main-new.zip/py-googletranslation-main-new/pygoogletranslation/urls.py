# -*- coding: utf-8 -*-
"""
Predefined URLs used to make google translate requests.
"""
BASE = 'https://translate.google.com'
TOKEN = 'https://translate.google.com/translate_a/element.js'
TRANSLATE = 'https://translate.googleapis.com/translate_a/'
TRANSLATEURL = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'